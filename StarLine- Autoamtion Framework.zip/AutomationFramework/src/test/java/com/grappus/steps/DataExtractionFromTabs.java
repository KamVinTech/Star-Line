package com.grappus.steps;

import com.grappus.utils.CommonMethods;
import com.grappus.utils.ConfigsReader;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;


public class DataExtractionFromTabs extends CommonMethods{

	@Given("User is already logged in")
	public void user_is_already_logged_in() {
		sendText(loginPage.userName, ConfigsReader.getProperty("username"));
		sendText(loginPage.password, ConfigsReader.getProperty("password"));
		click(loginPage.loginBtn);
		wait(2);
	}

	@When("user is on Home page")
	public void user_is_on_home_page() {
		Assert.assertTrue(mainPage.logo.isDisplayed());
		
	}

	@Then("Extract data from Tabs")
	public void extract_data_from_tabs() {
		// Write code here that turns the phrase above into concrete actions
		
		click(mainPage.Transactions);
		wait(2);
		getText(mainPage.RowData1);
		getText(mainPage.RowData2);
		getText(mainPage.RowData3);
		getText(mainPage.RowData4);
		
		
	}

	@Then("I validate the data is extracted")
	public void i_validate_the_data_is_extracted() {
		System.out.println("Data has been successfully extracted.");
		
	}
}
