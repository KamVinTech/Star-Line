package com.grappus.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.grappus.testbase.BaseClass;

public class LoginPage extends BaseClass{

	@FindBy(xpath = "//input[@type='password']")
	public WebElement password;

	@FindBy(xpath = "//input[@type='text']")
	public WebElement userName;

	@FindBy(xpath = "//button[@type='submit']")
	public WebElement loginBtn;

	/*
	 * @FindBy(xpath = "//h3 [@data-test='error']") public WebElement errorMsg;
	 */

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

}
