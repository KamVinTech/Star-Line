package com.grappus.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.grappus.testbase.BaseClass;

public class MainPage {

	@FindBy(xpath = "//img[contains(@class, 'mantine-Image-image')]")
	public WebElement logo;
	
	//Header Links
	
	@FindBy(xpath = "//span[contains(text(),'Transactions')]")
	public WebElement Transactions;
	
	@FindBy(xpath = "//span[contains(text(), 'Users')]")
	public WebElement Users;
	
	@FindBy(xpath = "//span[contains(text(), 'Deals')]")
	public WebElement Deals;
	
	@FindBy(xpath = "//span[contains(text(), 'Wealth Managers')]")
	public WebElement WealthManagers;
	
	@FindBy(xpath = "//span[contains(text(), 'Master')]")
	public WebElement Master;
	
	
	//Tabs of the table
	
	@FindBy(id="mantine-r3-tab-all")
	public WebElement Tab1;
	
	@FindBy(id="mantine-r3-tab-requested")
	public WebElement Tab2;
	
	@FindBy(id="mantine-r3-tab-approved")
	public WebElement Tab3;
	
	@FindBy(id="mantine-r3-tab-rejected")
	public WebElement Tab4;
	

	//To select the whole table
	
	@FindBy(xpath = "//table[contains(@class, 'mantine-1r9xmxd')][1]/tbody")
	public WebElement Table;
	
	//To get the data of each cell in the table. If you want to move to the next row, please remove the TD tag and just keep adding the numbers to Tr[n].
	
	@FindBy(xpath ="//table[contains(@class, 'mantine-1r9xmxd')][1]/tbody/tr/td[1]")
	public WebElement RowData1;
	
	@FindBy(xpath ="//table[contains(@class, 'mantine-1r9xmxd')][1]/tbody/tr/td[2]")
	public WebElement RowData2;
	
	@FindBy(xpath ="//table[contains(@class, 'mantine-1r9xmxd')][1]/tbody/tr/td[3]")
	public WebElement RowData3;
	
	@FindBy(xpath ="//table[contains(@class, 'mantine-1r9xmxd')][1]/tbody/tr/td[4]")
	public WebElement RowData4;
	
	@FindBy(xpath ="//table[contains(@class, 'mantine-1r9xmxd')][1]/tbody/tr/td[5]")
	public WebElement RowData5;
	
	
	
	

	public MainPage() {
		PageFactory.initElements(BaseClass.driver, this);
	}

}
