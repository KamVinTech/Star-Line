package com.grappus.steps;

import org.junit.Assert;

import com.grappus.utils.CommonMethods;
import com.grappus.utils.ConfigsReader;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends CommonMethods{

	@When("user enters valid username")
	public void user_enters_valid_username() {
		sendText(loginPage.userName, ConfigsReader.getProperty("username"));
	}

	@When("user enters valid password")
	public void user_enters_valid_password() {
		sendText(loginPage.password, ConfigsReader.getProperty("password"));
	}

	@When("click on login button")
	public void click_on_login_button() {
		click(loginPage.loginBtn);
		wait(2);
	}

	@Then("I validate that user is logged in")
	public void i_validate_that_user_is_logged_in() {
		Assert.assertTrue(mainPage.logo.isDisplayed());
	}


}
