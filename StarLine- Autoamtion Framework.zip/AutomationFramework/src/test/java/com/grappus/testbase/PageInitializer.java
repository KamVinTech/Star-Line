package com.grappus.testbase;

import com.grappus.pages.LoginPage;
import com.grappus.pages.MainPage;

public class PageInitializer extends BaseClass {

	public static LoginPage loginPage;
	public static MainPage mainPage;
	
 static void initialize() {
		// initialize pages
		loginPage = new LoginPage();
		mainPage = new MainPage();
		
	}

}
